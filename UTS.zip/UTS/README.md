Proyek ini adalah sebuah Website Portfolio Pribadi yang dibuat menggunakan HTML, CSS, dan Bootstrap. Website ini dirancang untuk menampilkan profil pribadi, pengalaman, prestasi, dan kontak secara profesional.
Proyek ini terdiri dari beberapa halaman:
index.html (Beranda) → Halaman utama yang memperkenalkan pemilik website.
portfolio.html → Menampilkan proyek-proyek atau pengalaman kerja.
prestasi.html → Menampilkan pencapaian dan sertifikasi.
contact.html → Berisi informasi kontak dan cara menghubungi pemilik website.
Setiap halaman menggunakan Bootstrap untuk tampilan responsif dan CSS khusus untuk mempercantik desain.